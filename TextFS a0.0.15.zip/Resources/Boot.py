# Unlike setting.py, this file is intended for
# preferences that are not meant to be changed
# in the later future.

Opened = 0