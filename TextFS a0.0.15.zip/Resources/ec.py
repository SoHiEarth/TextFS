# Error Codes, if you can read the 
# meaning of this code, you can
# edit this, but if not, just keep it
# alone, you'll still be happy.

# Error Codes and meanings.

class ec:
    class importe:
        importe = "Error importing required modules."
        importc = "2"
    class init:
        inite = "Error initiating program.\nMaybe you have a broken installation?"
        initc = "1"