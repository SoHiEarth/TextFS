SafeMode = 0
DebugMode = 1