class Program_Info:
    version = "a0.0.12"
    channel = "Nightly"
    name = "TextFS a0.0.12"
    pdesc = "Lots of stuff."
    changelog = ["Version 0.0.11 is a minor update to 0.0.1, including some bug fixes, and other things",
                 "version 0.0.1: Initial release, no game, just menu. Sorry.","Done."]