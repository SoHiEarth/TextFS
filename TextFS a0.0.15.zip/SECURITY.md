# Security Policy
I don't know what a security breach for a simulator is, report it as a major issue on GitHub, I'll try to respond as quickly as I can.
Just make sure that it's not a huge breach, and if it is, it'll be helpful if people can fix it on a different branch.
